package com.example.laundry_mawar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
